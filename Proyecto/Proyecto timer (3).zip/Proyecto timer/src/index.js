import './styles.scss';

document.addEventListener('DOMContentLoaded', () => {
  console.log("Timer listo para funcionar");
});
