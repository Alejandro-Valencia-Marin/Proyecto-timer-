export default {
    testEnvironment: 'node'
  };
  